package edu.montclair.mobilecomputing.m_alrajab.week11firebasechat;

import android.os.Bundle;

/**
 * Created by boris_000 on 5/4/2017.
 */

interface MainActivity2 {
    void onCreate2(Bundle savedInstanceState);
}
